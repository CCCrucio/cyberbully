
class StopTraining(Exception):
    """ Exception raised when the training is forced to stop. """
